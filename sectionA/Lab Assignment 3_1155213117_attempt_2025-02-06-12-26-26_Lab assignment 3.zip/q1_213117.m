a=1;
for n=2:100
    b=a/2+n.^2;
    a=b;
end