x=1
for i=2:100
    x=x/2+i*i;
end
x