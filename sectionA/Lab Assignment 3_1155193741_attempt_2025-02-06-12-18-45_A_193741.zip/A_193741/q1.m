x = 1;
count = 2;
for n=2:100
    x = x/2 + count^2;
    count = count + 1;
end

    