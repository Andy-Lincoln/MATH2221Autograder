% q1.m
a = 1;
for i = 2:100
    a = a/2 + i^2;
end
disp(a)