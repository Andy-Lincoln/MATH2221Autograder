M=zeros(3)
w=0
n=1

disp(M)
while w=0 && n<=9
    