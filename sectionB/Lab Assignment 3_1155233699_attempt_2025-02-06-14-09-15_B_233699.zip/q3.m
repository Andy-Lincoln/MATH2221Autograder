S = 0;
n = 0;

while S < 10
    n = n+1;
    S = S+1/n;
end

n