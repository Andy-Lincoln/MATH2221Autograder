x=1;
for n=2:100
    x=x/2+sqrt(n);
end
x