s = 0;
i = 1;
N = 0;
while s < 10
    s = s + 1 / i;
    i = i + 1;
    N = N + 1;
end

N