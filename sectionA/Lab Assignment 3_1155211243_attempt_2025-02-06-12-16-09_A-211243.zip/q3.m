i=1
Sn=0
while Sn<10
    Sn=Sn+1/i;
    i=i+1;
end
i