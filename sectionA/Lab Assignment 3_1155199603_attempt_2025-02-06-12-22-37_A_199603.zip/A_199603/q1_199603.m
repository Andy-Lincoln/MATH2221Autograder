x=1;
for m=1:100
 x=x/2+m^2;   
end
x