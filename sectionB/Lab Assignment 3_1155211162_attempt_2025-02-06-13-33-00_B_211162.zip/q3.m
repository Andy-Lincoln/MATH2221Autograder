% initialization
cnt = 0;
sum = 0;
std = 10;

% implementation
while sum < std
    cnt = cnt + 1;
    sum = sum + 1 / cnt;
end
LeastN = cnt
    