s=1;
for n=1:100    
    s=(s/2)+log10(n);
end
s