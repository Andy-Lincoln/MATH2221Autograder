s=1;
for i=2:100
    s=s/2+log(i);
end
s