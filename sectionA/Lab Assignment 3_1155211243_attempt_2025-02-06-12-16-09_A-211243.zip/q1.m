x1=1
for n=1:99
    x1=x1/2+(n+1)^2;
end


