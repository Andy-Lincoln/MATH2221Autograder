disp(M)
w=0
n=1
if mod(n,2)~=0
    disp("Player A")
else 
    disp("Player B")
end 
