s=0;
i=1;
while s<10
    i=i+1;
    s=s+1/i;
end
i