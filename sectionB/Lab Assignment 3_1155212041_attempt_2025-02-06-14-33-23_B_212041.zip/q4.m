M=zeros(3,3);
disp(M)
w=0;
n=1;
while (w==0) && (n<=9)
    if mod(n,2)==1
        disp("Player A");
    else
        disp("Player B");
    end
    v=0;
end
while v==0
    i=input('Please input the desired row number:');
    j=input('Please input the desired row number:');
    v=checkValid(M,i,j);
end
