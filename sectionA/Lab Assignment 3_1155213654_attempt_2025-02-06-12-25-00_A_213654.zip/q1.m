for n = 2:100
F(1)=1;
F(n)= F(n-1)/2+n^2;
end
F(100)
