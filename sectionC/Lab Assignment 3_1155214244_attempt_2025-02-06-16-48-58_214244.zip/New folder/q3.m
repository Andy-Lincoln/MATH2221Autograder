s = 1;
n = 2;
while s < 10
    s = 1/n + s;
    n = n + 1;
end
n
    

