x=1;
for s=2:100
    x=x/2+log(s);
end
x