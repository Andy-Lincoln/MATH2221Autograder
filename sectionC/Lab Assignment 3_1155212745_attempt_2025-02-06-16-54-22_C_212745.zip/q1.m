a=1;
for n=2:100
   b=a/2+log(n);
   a=b;
end
disp(a)