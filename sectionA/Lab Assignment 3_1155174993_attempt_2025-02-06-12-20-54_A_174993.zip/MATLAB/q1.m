a = 1;
for i = 2:100
    b = a/2 + i^2;
    a = b;
end
a