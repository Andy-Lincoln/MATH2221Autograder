S = 0;
i = 1;
while S < 10
    S = S + 1/i;
    i = i+1;
end
i
