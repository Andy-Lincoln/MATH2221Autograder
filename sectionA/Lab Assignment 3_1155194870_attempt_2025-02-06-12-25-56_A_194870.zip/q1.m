x = 0;
for n = 2:100
    x = 0.5*x + n^2;
end
x