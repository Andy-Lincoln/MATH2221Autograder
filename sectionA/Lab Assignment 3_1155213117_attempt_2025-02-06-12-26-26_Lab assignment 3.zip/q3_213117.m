s_n=0;
n=0;

while S(n)<10
    n=n+1;
    S(n)=S(n)+1/n;
end

n=num2str(n)