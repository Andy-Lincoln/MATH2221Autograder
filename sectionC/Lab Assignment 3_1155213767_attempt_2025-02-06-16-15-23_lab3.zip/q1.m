x = 1;
for i = 1:100
 x = (x/2) + log(i);
end
x