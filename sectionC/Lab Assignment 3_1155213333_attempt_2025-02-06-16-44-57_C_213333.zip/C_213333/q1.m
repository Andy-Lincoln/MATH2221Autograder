x = 1
for i = 1:99
    x = x/2+log(i+1);
end
