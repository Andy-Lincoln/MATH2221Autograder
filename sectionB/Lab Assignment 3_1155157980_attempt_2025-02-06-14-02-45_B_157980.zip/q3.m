n = 1;
S = 0;
while S < 10
    
    n = n + 1;
    S = 0;
    for i = 1:n
        S = S + 1/i;
    end
end

n