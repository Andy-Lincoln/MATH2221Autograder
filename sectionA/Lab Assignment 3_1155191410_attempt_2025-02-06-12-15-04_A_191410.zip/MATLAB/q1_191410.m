x(1)=1
s=1
for i=2:100
    x(i)=x(i-1)/2+i^2;
end
x(100)
