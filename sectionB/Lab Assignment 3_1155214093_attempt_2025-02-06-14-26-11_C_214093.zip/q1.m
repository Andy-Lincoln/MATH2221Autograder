s=1
for i = 2:100
    s = s/2 + sqrt(i);
end
s