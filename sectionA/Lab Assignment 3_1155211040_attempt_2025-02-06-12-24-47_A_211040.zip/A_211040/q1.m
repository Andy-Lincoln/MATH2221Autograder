x=1;
for n=2:100
    x=x/2+n^2;
end
x