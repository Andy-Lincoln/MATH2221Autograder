n = 0
s = 0
while s < 10
    n = n+1
    s = s + 1/n
end

