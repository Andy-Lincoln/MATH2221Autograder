x=0;n=2;while n<=100
x=(x/2)+log(n);n=n+1
end
x