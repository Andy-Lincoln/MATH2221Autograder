Sn=0;
n=0;

while Sn<10
n=n+1;
Sn=Sn+(1/n);
end

n