a=1;

for n=2:100
    c=(a/2)+log10(n);
    a=c;
end

c 
