S = 0;
n = 1;
while S < 10
    S = S + 1/n;
    n = n + 1;
end
n = n-1;
n