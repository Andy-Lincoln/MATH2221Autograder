s = 0
j = 1
while s < 10
    s = s + 1/j;
    j = j + 1;
end

j - 1