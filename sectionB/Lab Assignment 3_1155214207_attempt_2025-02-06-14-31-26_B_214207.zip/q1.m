n = 100
s = 1

for i = 2:n
    s = s/2 + i^0.5;
end

s