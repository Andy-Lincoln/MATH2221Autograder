sum = 0;
i = 1;
n = 0;
while sum < 10
    sum = sum + 1/i;
    i = i + 1;
    n = n + 1;
end

    
    