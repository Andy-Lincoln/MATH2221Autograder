function w= checkWin(M)
sum(M,1)
if 
    disp('player A win');
elseif sum(M,2)
    disp('player B win')
elseif 