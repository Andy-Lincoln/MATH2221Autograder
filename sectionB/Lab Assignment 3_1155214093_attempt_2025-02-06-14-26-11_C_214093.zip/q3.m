s=0
n=1
while s < 10
    s = s+ 1/n;
    n = n+1;
end

n-1