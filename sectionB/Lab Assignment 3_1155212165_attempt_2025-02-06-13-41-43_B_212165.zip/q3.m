S = 0;
i = 0;
while S < 10
    i = i + 1;
    S = S + 1/i;
end
i