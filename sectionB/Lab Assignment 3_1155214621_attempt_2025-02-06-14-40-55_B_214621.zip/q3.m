S = 0;
i = 1;
while S < 10
    S = S + 1/i;
    if S >= 10
        n = i;
    end
    i = i + 1;
end
n