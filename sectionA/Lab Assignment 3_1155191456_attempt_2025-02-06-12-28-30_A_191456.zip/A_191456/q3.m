n = 1;
Sn = 0;
while Sn < 10
    Sn = Sn + 1/n;
    n = n + 1;
end
n = n - 1;
n