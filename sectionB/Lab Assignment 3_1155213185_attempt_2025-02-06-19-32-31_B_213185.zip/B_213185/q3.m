function n = q3
currentValue = 0;
n=0;
while currentValue < 10
    n = n+1;
    currentValue = currentValue + 1/n;
end

    