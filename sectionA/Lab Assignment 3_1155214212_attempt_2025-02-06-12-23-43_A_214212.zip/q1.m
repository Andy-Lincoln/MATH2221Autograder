s=1;
for i=1:100
    s=s/2+i^2
end
s