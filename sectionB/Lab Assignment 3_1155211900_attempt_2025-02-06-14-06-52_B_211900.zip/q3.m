function n = q3
    x = 0;
    n = 0;
    while x < 10
        n = n + 1;
        x = x + 1/n;
    end
end