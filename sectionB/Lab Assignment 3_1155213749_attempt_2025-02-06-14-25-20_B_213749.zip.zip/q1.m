x=1;

for i =1:99
    x=x/2+sqrt(i+1)
end