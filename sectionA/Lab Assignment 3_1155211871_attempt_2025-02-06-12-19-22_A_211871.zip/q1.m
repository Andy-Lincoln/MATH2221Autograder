a=1;
for b=2:100
    c=a/2+b^2;
    a=c;
end
c