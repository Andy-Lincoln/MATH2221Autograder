s=0;
n=0;
while s<=10
    n=n+1;
    s=1/n+s;
end
n