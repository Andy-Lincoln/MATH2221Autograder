x100=1;
for i=2:100;
    x100=x100/2+log(i);
end
x100