sum = 0;
n = 0;
while sum < 10
    n = n + 1;
    sum = sum + 1/n;
end
n
    