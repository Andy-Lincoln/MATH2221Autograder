term = 1;
for i = [2:100]
    term = term / 2 + sqrt(i);
end
term