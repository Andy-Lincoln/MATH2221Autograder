x=1;
for i=2:100
    x=0.5*x+sqrt(i);
end

x