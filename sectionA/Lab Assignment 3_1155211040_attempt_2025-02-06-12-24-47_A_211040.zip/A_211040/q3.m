s=0;
n=0;
while s<10
    s=s+1/(n+1);
    n=n+1;
end
n