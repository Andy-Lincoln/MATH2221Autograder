s=0;
n=1;
while s<=10
    s=s+1/n;
    n=n+1;
end
n

n=12367;
sum=0;
for i=1:n
    sum =sum+1/i;
end
sum