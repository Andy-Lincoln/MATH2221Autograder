x=1;
for i=2:100
   x=x/2+i^2;
   x
end
