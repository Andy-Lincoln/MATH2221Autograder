s = 1
for i = 1:100
    s = s/2+log(i)
end
s