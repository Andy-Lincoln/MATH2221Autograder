s=0;
i=1;
while s>=10
   s=s+1/i;
end

    